//
//  RequestLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class RequestLimitIncrease {
    var accountInfo = [
        "S1100" : Acinfo(type: "Saving", balance: 2313.54),
        "S1200" : Acinfo(type: "Saving", balance: 4500.54),
        "S1300" : Acinfo(type: "Cheqing", balance: 5313.54),
        "S1400" : Acinfo(type: "Saving", balance: 7313.54)
    ]
    
    func processRequest(accountno: String) throws {
        guard let accNo =  accountInfo[accountno]
            else {
                throw LimitIncreaseErrors.ineligible
        }
        guard accNo.type == "Saving" else {
            throw LimitIncreaseErrors.noSavingAc
        }
        
        guard accNo.balance >= 500 else {
            throw
            LimitIncreaseErrors.insufficientBalance
        }
        print("Congrats")
    }
    
}
struct Acinfo {
    var type : String
    var balance : Double
}

enum LimitIncreaseErrors : Error {
    case ineligible
    case noSavingAc
    case insufficientBalance
}
