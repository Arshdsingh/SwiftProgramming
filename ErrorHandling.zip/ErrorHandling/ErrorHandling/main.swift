//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

do {
    try request1.processRequest(accountno: "S1100")
} catch LimitIncreaseErrors.ineligible {
    print("You Dont Have Account With Our Bank")
}   catch LimitIncreaseErrors.noSavingAc {
    print("No Saving Account")
}   catch LimitIncreaseErrors.insufficientBalance {
    print("Insufficient Balance")
}   catch {
    print("Sorry For Inconvenience")
}


var s1 = Student()
s1.name = "Arsh"
s1.display()

var s2 = Student()
s2.name = "Jatinder"
s2.display()
