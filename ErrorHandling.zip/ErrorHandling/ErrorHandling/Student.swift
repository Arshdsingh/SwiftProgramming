//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Student {
    var name : String?
    private static var accno : Int?
    
    init() {
        self.name = ""
        Student.accno = 12345
    }
    
    func display() {
        print("Student Name : \(self.name ?? "Unknown")")
        print("Account No : \(Student.accno ?? 0)")
    }
    
    static func AccNo() -> Int {
        return accno!
    }
}


class PartTime  : Student {
    var hours : Int?
    override init() {
        self.hours = 0
        super.init()
    }
    
    override func display() {
        print("Hours : \(self.hours ?? 0)")
    }
}
