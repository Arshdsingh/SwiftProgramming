//
//  PassengerDataHelper.swift
//  GARS
//
//  Created by Govinda Sharma on 2018-07-31.
//  Copyright © 2018 Govinda Sharma. All rights reserved.
//

import Foundation

class PassengerDataHelper {
    var passengers = [Int : Passenger]()
    
    init() {
        self.loadPassengers()
    }
    
    func loadPassengers(){
    }
    
    func displayPassengers(){
        for(_, passenger) in passengers.sorted(by: {$0.key < $1.key}){
            print("\(passenger.displayData())")
        }
    }
    
    func displayPassengerIds(){
        for(_, passenger) in passengers.sorted(by: {$0.key < $1.key}){
            print("\(passenger.displayUserID())")
        }
    }
    
    func deletePassengerWithId(empID: Int){
        passengers.removeValue(forKey: empID)
    }
    
    func addPassenger() -> Passenger{
//        print("Enter the Passenger ID:")
//        var psngrID = (Int)(readLine()!)!
        let psngr = Passenger().enterPassengerDetails()
        if passengerExistsWith(psngrID: psngr.id){
            reEnterIDForPassenger(psngr: psngr)
        } else {
            passengers[psngr.id] = psngr
        }
        return psngr
    }
    
    func reEnterIDForPassenger(psngr: Passenger){
        print("Please enter different Passenger ID:")
        if passengerExistsWith(psngrID: (Int)(readLine()!)!){
            reEnterIDForPassenger(psngr: psngr)
        } else {
            passengers[psngr.id] = psngr
        }
    }
    
    func passengerExistsWith(psngrID: Int) -> Bool {
        var userInvalid: Bool
        if passengers[psngrID] == nil{
            userInvalid = false
        } else {
            userInvalid = true
        }
        return userInvalid
    }
}
