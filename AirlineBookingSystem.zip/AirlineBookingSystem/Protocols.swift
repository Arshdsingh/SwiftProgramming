//
//  Protocols.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
protocol IDisplay{
    func display()
}

protocol INetPayCalculation {
    var netPay : Double? {get}
    
    init(empID: Int, empName: String, basicPay: Double, holiday: Int)
}
