//
//  main.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


var dataHelper = DataHelper()
dataHelper.displayAirline()

var Vishank = Passenger()
Vishank.addPassenger()
print(Vishank.displayData())
let dateCurrent = Date()
print("Date 1 : \(dateCurrent)")

let dateString = "12/01/2003"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "MM/dd/yyyy"
let dateFromString = dateFormatter.date(from: dateString)
print("Date 2 : \(dateFromString!)")
