//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var arsh = Customer()


var jatinder = Customer(customerid: 1, customername: "Jatinder|", address: "332,Ellesmere Road|", email: "jatinder@jtt.com|", creditcardinfo: "23242345353454|", shoppinginfo: "Scarborough|")

arsh.CustomerID = 2
arsh.CustomerName = "Arsh|"
arsh.CustomerCard = "12343534634|"
arsh.CustomerAddress = "Malton|"
arsh.ShoppingInfo = "Mississauga|"

print(arsh.displaydata())
print("||====================||")
print(jatinder.displaydata())

var simran = Customer()

simran.registeruser()
print(simran.displaydata())
