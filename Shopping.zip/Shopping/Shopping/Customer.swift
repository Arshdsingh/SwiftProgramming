//
//  Customer.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Customer{
    private var customerid : Int?
    private var customername : String?
    private var address : String?
    private var email : String?
    private var creditcardinfo : String?
    private var shoppinginfo : String?
    
    //default initializer(Constructor)
    init() {
        self.customerid = 0
        self.customername = ""
        self.address = ""
        self.email = ""
        self.creditcardinfo = ""
        self.shoppinginfo = ""
    }
    
    //parameterised constructor
    
    init(customerid : Int,customername : String,address : String,email : String,creditcardinfo : String,shoppinginfo : String)
        {
            self.customerid = customerid
            self.customername = customername
            self.address = address
            self.email = email
            self.creditcardinfo = creditcardinfo
            self.shoppinginfo = shoppinginfo
    }
    
    //stored property
    var CustomerID : Int? {
        get{return self.customerid}
        set{self.customerid = newValue}
    }
    var CustomerName : String? {
        get{return self.customername}
        set{self.customername = newValue}
    }
    var CustomerAddress : String? {
        get{return self.address}
        set{self.address = newValue}
    }
    var CustomerCard : String? {
        get{return self.creditcardinfo}
        set{self.creditcardinfo = newValue}
    }
    var ShoppingInfo : String? {
        get{return self.shoppinginfo}
        set{self.shoppinginfo = newValue}
    }
    
    func displaydata() -> String {
        var data = ""
        
        if self.customerid != nil {
           data += "customerid : \(customerid ?? 0)"
        }
        if self.customername != nil {
            data += "customer name : \(customername ?? "Data Missing")"
        }
        if self.address != nil {
            data += "address : \(address ?? "Data Missing")"
        }
        if self.email != nil {
            data += "email : \(email ?? "Data Missing")"
        }
        if self.creditcardinfo != nil {
            data += "credit card info : \(creditcardinfo ?? "Data Missing")"
        }
        if self.shoppinginfo != nil {
            data += "shopping info : \(shoppinginfo ?? "Data Missing")"
        }
        return data
    }
    func registeruser() {
        print("Enter Customer Id")
        self.CustomerID = (Int)(readLine()!)
        print("Enter Customer Name")
        self.CustomerName = readLine()!
        print("Enter Customer Address")
        self.CustomerAddress = readLine()!
        print("Enter Cardinfo")
        self.CustomerCard = readLine()!
        print("Enter Shipping Info")
        self.ShoppingInfo = readLine()!
    }
    
    
}
