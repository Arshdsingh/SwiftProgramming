//
//  main.swift
//  employee
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var jtndr = PermanentEmp(empID: 110, empName: "jtndr", basicPay: 100000.00, holiday: 3)
jtndr.display()

var arsh =  Tempemp(empID: 111, empName: "Arsh", basicPay: 5000, holiday: 100)
arsh.display()


print("7 is prime number : \(7.isPrime)")

4.wish {
    print("H a p p y B i r t h d a y")
}


print(588424242[6])
