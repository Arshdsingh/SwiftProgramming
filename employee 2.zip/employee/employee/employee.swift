//
//  employee.swift
//  employee
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class employee :IDisplay {
    
    
    
    var empID :Int?
    var empName : String?
    var basicPay : Double?
    
    init() {
        self.empID = 0
        self.empName = ""
        self.basicPay = 0.0
    }
    init(empID : Int,empName : String,basicPay: Double) {
        self.empID = empID
        self.empName = empName
        self.basicPay = basicPay
        
    }
    
    
    func display(){
        print("EmpID : \(self.empID ?? 0)")
        print("Emp Name : \(self.empName ?? "unknown")")
        print("Emp Basic Pay : \(self.basicPay?.asCurrency ?? "Data Missing")")
        
        
    }
    
    //deinitializer
    // garbage collector
    
    
    deinit {
        print("after resignign job  ..........")
    }
}
